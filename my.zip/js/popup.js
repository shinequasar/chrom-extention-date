function calculateDate(){
    var startDate = new Date('29/08/2020 00:00:00');
    var nowDate = new Date();
    var dDay = nowDate - startDate;

    var esDay = d;
    document.getelementbyid('title').innerText = "dmmm";
    // document.body.innerText = nowTime;
}
window.onload = calculateDate;